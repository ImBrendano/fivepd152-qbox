﻿This is a beta release! It was not tested in depth and may contain many bugs and/or glitches.
Only install it, if you agree with this and want to help me during development by posting bug reports/feature requests. 

------------------------------
Description:
------------------------------
This mod aims to add some audio to FivePD.
Currently it only adds Dispatch audio for new callouts and backup requests.

------------------------------
Installation Instructions:
------------------------------
1. Extract the fivepdaudio folder into your resources folder
2. Add "start fivepdaudio" to your server.cfg (without the quotation marks)
3. Restart the server

------------------------------
Chat Commands:
------------------------------
/audio volume PERCENTAGE
/audio debug TRUE/FALSE

------------------------------
Links:
------------------------------
Installation guide, troubleshooting, customization options, developer guides and more on my wiki:
https://gitlab.pbogi.com/bogi/fivepdaudio/-/wikis/home

Download the latest version from:
https://gtapolicemods.com/index.php?/files/file/895-fivepd-audio-beta-dispatch-audio
------------------------------